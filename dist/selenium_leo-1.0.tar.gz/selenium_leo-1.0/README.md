# Este modulo contiene funciones útiles para trabajar con selenium en python

"""Funciones:

- send_key_as_human: Envia una cadena de texto una a una con un tiempo random entre 0.15 a 0.40 segundos

- doble_selector_xpath: Se le pasa 2 dirección de selectores y el tiempo de espera, si el primero falla usa el segundo.

y otros mas de doble selector...
"""

